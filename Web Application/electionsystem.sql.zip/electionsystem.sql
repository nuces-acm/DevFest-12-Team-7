-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 01, 2012 at 09:14 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `electionsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE IF NOT EXISTS `candidate` (
  `candidate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `candidate_name` varchar(30) NOT NULL,
  `area_c` decimal(5,0) unsigned NOT NULL,
  `party_name` varchar(15) NOT NULL,
  PRIMARY KEY (`candidate_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`candidate_id`, `candidate_name`, `area_c`, `party_name`) VALUES
(1, 'Tauqeer Nasir', '54000', 'Peoples Party'),
(2, 'Shahaab', '54060', 'PTI');

-- --------------------------------------------------------

--
-- Table structure for table `election`
--

CREATE TABLE IF NOT EXISTS `election` (
  `election_date` date NOT NULL,
  `election_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` int(10) unsigned NOT NULL,
  `voter_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`election_id`),
  UNIQUE KEY `voter_id_2` (`voter_id`),
  KEY `candidate_id` (`candidate_id`),
  KEY `voter_id` (`voter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `election`
--

INSERT INTO `election` (`election_date`, `election_id`, `candidate_id`, `voter_id`) VALUES
('2012-04-01', 18, 1, 20),
('2012-04-01', 20, 1, 22),
('2012-04-01', 21, 1, 23);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `NIC` decimal(30,0) NOT NULL,
  `username` varchar(13) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `type` varchar(9) NOT NULL,
  `name` varchar(30) NOT NULL,
  `family_code` varchar(6) NOT NULL,
  `area_c` int(6) unsigned NOT NULL,
  `voted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`username`,`password`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`NIC`, `username`, `password`, `type`, `name`, `family_code`, `area_c`, `voted`) VALUES
('3520220198169', 'haider', 'abbas', 'admin', 'Haider Abbas', '21', 54000, 1),
('123123123', 'haider abbas', 'haider', 'user', 'Haider Abbas', '21', 12312, 0),
('12345', 'hakeem', 'hakeem', 'user', 'Hakeem Abbas', 'OKV2', 54000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `voter`
--

CREATE TABLE IF NOT EXISTS `voter` (
  `voter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `voter_username` varchar(13) NOT NULL,
  `voter_area_c` int(6) unsigned NOT NULL,
  `voted` tinyint(1) NOT NULL,
  PRIMARY KEY (`voter_id`),
  KEY `voter_username` (`voter_username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `voter`
--

INSERT INTO `voter` (`voter_id`, `voter_username`, `voter_area_c`, `voted`) VALUES
(20, '', 0, 1),
(21, '', 0, 1),
(22, 'haider', 54000, 1),
(23, 'hakeem', 54000, 1);
